enum CameraMode { live, playback }
