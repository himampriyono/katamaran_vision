import 'package:flutter/material.dart';
import '../enums/camera_id.dart';
import '../services/camera_manager.dart';
import '../services/camera_session.dart';

class RecordPanel extends StatelessWidget {
  const RecordPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final manager = CameraManager.instance;

    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _buildRow(manager.get(CameraId.front)),
          const SizedBox(height: 8),
          _buildRow(manager.get(CameraId.left)),
          const SizedBox(height: 8),
          _buildRow(manager.get(CameraId.rear)),
          const SizedBox(height: 8),
          _buildRow(manager.get(CameraId.right)),
        ],
      ),
    );
  }

  Widget _buildRow(CameraSession session) {
    return ValueListenableBuilder(
      valueListenable: session.recording.isRecording,
      builder: (_, recording, _) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF202535),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 84,
                child: Text(
                  session.config.name.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  recording ? "Recording..." : "Idle",
                  style: TextStyle(
                    color: recording ? Colors.red : Colors.grey.shade400,
                    fontSize: 12,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  recording ? "00:00:00" : "---",
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
              InkWell(
                onTap: () {
                  recording
                      ? session.stopRecording()
                      : session.startRecording();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  width: 84,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: recording ? Colors.red : Colors.orange,
                      width: 0.5,
                    ),
                    color: recording
                        ? Colors.red.withAlpha(150)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        recording ? Icons.stop : Icons.fiber_manual_record,
                        color: recording ? Colors.white : Colors.red,
                        size: 18,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        recording ? "STOP" : "START",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
