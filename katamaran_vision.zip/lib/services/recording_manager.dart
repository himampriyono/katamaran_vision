import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as path;
import '../models/camera_config.dart';
import '../utils/utils.dart';
import '../enums/camera_id.dart';
import 'package:media_kit/media_kit.dart';

class RecordingManager {
  RecordingManager({required CameraConfig config, required NativePlayer player})
    : _config = config,
      _player = player;

  CameraConfig _config;
  final NativePlayer _player;

  final ValueNotifier<bool> isRecording = ValueNotifier(false);

  Future<void> start() async {
    if (isRecording.value) {
      return;
    }

    final output = await Utils.generateVideoPath(_cameraName());

    debugPrint("Record: $output");

    await _player.setProperty("stream-record", output);

    final check = await _player.getProperty("stream-record");
    debugPrint("stream-record value: $check");

    isRecording.value = true;
  }

  Future<void> stop() async {
    if (!isRecording.value) {
      return;
    }

    await _player.setProperty("stream-record", "");

    isRecording.value = false;
  }

  // RecordingManager({required CameraConfig config}) : _config = config;

  // CameraConfig _config;
  // Process? _process;
  // File? _outputPath;
  // File? get outputPath => _outputPath;

  // final ValueNotifier<bool> isRecording = ValueNotifier(false);

  // void updateConfig(CameraConfig config) {
  //   _config = config;
  // }

  // Future<void> start() async {
  //   if (isRecording.value) {
  //     return;
  //   }

  //   final outputPath = await Utils.generateVideoPath(_cameraName());

  //   _process = await Process.start(Utils.ffmpegPath, [
  //     "-y",
  //     "-nostats",
  //     "-loglevel",
  //     "error",
  //     "-rtsp_transport",
  //     "tcp",
  //     "-i",
  //     _config.rtspUrl,
  //     "-c",
  //     "copy",

  //     "-tag:v",
  //     "hvc1",
  //     outputPath,
  //   ]);

  //   // ffmpeg -y -rtsp_transport tcp -i "rtsp://192.168.137.78:8554/cam2" -c copy -tag:v hvc1 "C:\Users\Himam\Documents\Videos\test.mp4"

  //   _process!.exitCode.then((code) {
  //     debugPrint("FFmpeg exited: $code");
  //   });

  //   // _process!.stdout.transform(SystemEncoding().decoder).listen(debugPrint);

  //   // _process!.stderr.transform(SystemEncoding().decoder).listen(debugPrint);

  //   isRecording.value = true;
  // }

  // Future<void> stop() async {
  //   if (!isRecording.value) {
  //     return;
  //   }

  //   _process?.stdin.write('q');
  //   await _process?.stdin.flush();

  //   final code = await _process?.exitCode.timeout(
  //     const Duration(seconds: 7),
  //     onTimeout: () {
  //       debugPrint("FFmpeg didn't exit, killing...");
  //       _process?.kill();
  //       return -1;
  //     },
  //   );

  //   debugPrint("FFmpeg Exit Code: $code");

  //   _process = null;
  //   isRecording.value = false;
  // }

  // Future<void> dispose() async {
  //   await stop();
  //   isRecording.dispose();
  // }

  String _cameraName() {
    switch (_config.id) {
      case CameraId.front:
        return "Front";

      case CameraId.left:
        return "Left";

      case CameraId.rear:
        return "Rear";

      case CameraId.right:
        return "Right";
    }
  }
}
